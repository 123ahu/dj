from django.shortcuts import render, redirect
from Medicioapp.models import contacts, Member
from django.shortcuts import render, redirect
from Medicioapp.models import appointment

# Create your views here.
def index(request):
    if request.method == 'POST':
        if Member.objects.filter(username=request.POST['username'],
                                 password=request.POST['password']).exists():
            members = Member.objects.get(
                username= request.POST['username'],
                password=request.POST['password']
            )
            return render(request, 'index.html', {'members':members})
        else:
            return render(request, 'login.html')
    else:
            return render(request, 'login.html')

def inner(request):
    return render(request, 'inner-page.html')
def about (request):
    return render(request, 'about.html')
def doctors(request):
    return render(request, 'doctors.html')
def department(request):
    return render(request, 'Departments.html')
def login(request):
    return render(request, 'login.html')


def Contacts(request):
    if request.method == 'POST':
        all = contacts(Name=request.POST['Name'],
                       email=request.POST['email'],
                       phone=request.POST['phone'],
                       message=request.POST['message'])
        all.save()
        return redirect('/contact')
    else:
        return render(request,'contacts.html')
def Appointments(request):
    if request.method == 'POST':
        myappointments = appointment(name=request.POST['name'],
                           email=request.POST['email'],
                           phone=request.POST['phone'],
                           date=request.POST['date'],
                           department=request.POST['department'],
                           doctor=request.POST['doctor'],
                           message=request.POST['message'])
        myappointments.save()
        return redirect('/appointment')
    return render(request, 'appointment.html')
def show(request):
    information = appointment.objects.all()
    return render(request, 'show.html', {'data':information})
def delete(request, id):
    myappointment = appointment.objects.get(id=id)
    myappointment.delete()
    return redirect('/show')
def signup(request):
    if request.method == 'POST':
        members= Member(
            name = request.POST['name'],
            username = request.POST['username'],
            password = request.POST['password'],
        )
        members.save()
        redirect('/login')
    else:
        return render(request, 'signup.html')
