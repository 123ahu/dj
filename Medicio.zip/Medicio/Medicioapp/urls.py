
from django.contrib import admin
from django.urls import path
from Medicioapp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('home/', views.index, name='index'),
    path('inner/', views.inner, name='inner'),
    path('about/', views.about, name='about'),
    path('doctors/', views.doctors, name='doctors'),
    path('Departments/', views.department, name='Departments'),
    path('contacts/', views.Contacts, name='Contacts'),
    path('appointment/', views.Appointments, name='appointment'),
    path('show/', views.show, name='show'),
    path('delete/<int:id>', views.delete, ),
    path('login/',views.login,name='login'),
    path('',views.signup,name='signup'),
]
