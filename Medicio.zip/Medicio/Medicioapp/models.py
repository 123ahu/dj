from django.db import models

# Create your models here.
class product(models.Model):
    name = models.CharField(max_length=200)
    quantity = models.IntegerField()
    price = models.CharField(max_length=200)
    color = models.CharField(max_length=20)
    description = models.TextField()


def __str__(self):
        return self.name

class Branch(models.Model):
    name = models.CharField(max_length=200)
    location = models.CharField(max_length=100)
    Manager = models.CharField(max_length=100)
    email = models.EmailField()


def __str__(self):
        return self.name
class contacts(models.Model):
    Name = models.CharField(max_length=200)
    email = models.CharField(max_length=100)
    phone = models.CharField(max_length=10)
    message = models.CharField(max_length=500)


def __str__(self):
        return self.Name
class appointment(models.Model):
    name = models.CharField(max_length=200)
    email = models.EmailField(max_length=100)
    phone = models.CharField(max_length=10)
    date = models.DateField(max_length=100)
    department = models.CharField(max_length=200)
    doctor = models.CharField(max_length=200)
    message = models.CharField(max_length=500)


def __str__(self):
    return self.name
class Member(models.Model):
    name=models.CharField(max_length=200)
    username=models.CharField(max_length=200)
    password=models.CharField(max_length=200)
