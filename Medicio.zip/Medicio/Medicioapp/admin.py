from django.contrib import admin
from Medicioapp.models import product
from Medicioapp.models import Branch
from Medicioapp.models import contacts
from Medicioapp.models import appointment
from Medicioapp.models import Member

# Register your models here.
admin.site.register(product)
admin.site.register(Branch)
admin.site.register(contacts)
admin.site.register(appointment)
admin.site.register(Member)
